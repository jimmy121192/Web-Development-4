<?php


function setConnectionInfo($values=array()) {
      $connString = $values[0];
      $user = $values[1]; 
      $password = $values[2];

      $pdo = new PDO($connString,$user,$password);
      $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      return $pdo;      
}


function runQuery($pdo, $sql, $parameters=array())     {
    // Ensure parameters are in an array
    if (!is_array($parameters)) {
        $parameters = array($parameters);
    }

    $statement = null;
    if (count($parameters) > 0) {
        // Use a prepared statement if parameters 
        $statement = $pdo->prepare($sql);
        $executedOk = $statement->execute($parameters);
        if (! $executedOk) {
            throw new PDOException;
        }
    } else {
        // Execute a normal query     
        $statement = $pdo->query($sql); 
        if (!$statement) {
            throw new PDOException;
        }
    }
    return $statement;
}


function readAllCustomers() {
    $pdo = setConnectionInfo(array(DBCONNECTION, DBUSER, DBPASS));
    $statement = runQuery($pdo, "SELECT * FROM customers", null);
    return $statement;
}
function readSelectCustomers($lastName) {
    $pdo = setConnectionInfo(array(DBCONNECTION, DBUSER, DBPASS));
    $statement = runQuery($pdo, "SELECT * FROM customers WHERE LastName Like ? ORDER BY LastName;", Array($lastName . '%'));
    return $statement ;
}
function readCustomerName($custid) {
    $pdo = setConnectionInfo(array(DBCONNECTION, DBUSER, DBPASS));
    $statement = runQuery($pdo, "SELECT * FROM customers WHERE ID = $custid", null);
	$name = $statement->fetch(PDO::FETCH_ASSOC); 
	// $statement->fetch(PDO::FETCH_ASSOC) converts the $statement PDO to an array so that we don't // have to use foreach loop (which also converts a PDO to an array) for a single customer
    return $name;
}
function readCustomerOrders($custid) {
    $pdo = setConnectionInfo(array(DBCONNECTION, DBUSER, DBPASS));
    $statement = runQuery($pdo, "SELECT * FROM orders WHERE ID = $custid", null);
    return $statement;
}
function readCategories() {
    $pdo = setConnectionInfo(array(DBCONNECTION, DBUSER, DBPASS));
    $statement = runQuery($pdo, "SELECT CategoryName FROM Categories;", null);
    $caties = $statement->fetchAll(PDO::FETCH_ASSOC); 
    return $caties;
}
function readImprints() {
    $pdo = setConnectionInfo(array(DBCONNECTION, DBUSER, DBPASS));
    $statement = runQuery($pdo, "SELECT Imprint FROM Imprints;", null);
    $prints = $statement->fetchAll(PDO::FETCH_ASSOC); 
    return $prints;
}


?>
