-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 02, 2019 at 04:23 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `books`
--

DROP DATABASE IF EXISTS `books`;
CREATE DATABASE IF NOT EXISTS `books`;
USE `books`;

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
CREATE TABLE IF NOT EXISTS `customers` (
  `ID` int(11) NOT NULL,
  `FirstName` varchar(255) DEFAULT NULL,
  `LastName` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `University` varchar(255) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `City` varchar(255) DEFAULT NULL,
  `Province` varchar(255) DEFAULT NULL,
  `Country` varchar(255) DEFAULT NULL,
  `PostCode` varchar(255) DEFAULT NULL,
  `Phone` varchar(255) DEFAULT NULL,    
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`ID`, `FirstName`, `LastName`, `Email`, `University`, `Address`, `City`, `Province`, `Country`, `PostCode`, `Phone`) VALUES
(2, 'Leonie', 'Köhler', 'leonekohler@surfeu.de', 'University of Stuttgart', 'Theodor-Heuss-Straße 34', 'Stuttgart', '', 'Germany', '70174', '+49 0711 2842222'),
(3, 'Bjørn', 'Hansen', 'bjorn.hansen@yahoo.no', 'University of Oslo', 'Ullevålsveien 14', 'Oslo', '', 'Norway', '0171', '+47 22 44 22 22'),
(4, 'François', 'Tremblay', 'ftremblay@gmail.com', 'McGill University', '1498 rue Bélanger', 'Montréal', 'QC', 'Canada', 'H2G 1A7', '+1 (514) 721-4711'),
(5, 'František', 'Wichterlová', 'frantisekw@jetbrains.com', 'Charles University', 'Klanova 9/506', 'Prague', '', 'Czech Republic', '14700', '+420 2 4172 5555'),
(6, 'Astrid', 'Gruber', 'astrid.gruber@apple.at', 'Vienna University of Technology', 'Rotenturmstraße 4', 'Vienna', '', 'Austria', '1010', '+43 01 5134505'),
(7, 'Helena', 'Holý', 'hholy@gmail.com', 'Charles University', 'Rilská 3174/6', 'Prague', '', 'Czech Republic', '14300', '+420 2 4177 0449'),
(16, 'Aaron', 'Mitchell', 'aaronmitchell@yahoo.ca', 'University of Manitoba', '696 Osborne Street', 'Winnipeg', 'MB', 'Canada', 'R3L 2B9', '+1 (204) 452-6452'),
(17, 'Ellie', 'Sullivan', 'ellie.sullivan@shaw.ca', 'Aurora College', '5112 48 Street', 'Yellowknife', 'NT', 'Canada', 'X1A 1N6', '+1 (867) 920-2233'),
(18, 'João', 'Fernandes', 'jfernandes@yahoo.pt', 'University of Lisbon', 'Rua da Assunção 53', 'Lisbon', '', 'Portugal', '', '+351 (213) 466-111'),
(19, 'Madalena', 'Sampaio', 'masampaio@sapo.pt', 'University of Porto', '4350 Rua dos Campeões Europeus de Viena', 'Porto', '', 'Portugal', '', '+351 (225) 022-448'),
(22, 'Isabelle', 'Mercier', 'isabelle_mercier@apple.fr', 'University of Burgundy', '68 Rue Jouvence', 'Dijon', '', 'France', '21000', '+33 03 80 73 66 99'),
(23, 'Emma', 'Jones', 'emma_jones@hotmail.com', "King's College", '202 Hoxton Street', 'London', '', 'United Kingdom', 'N1 5LH', '+44 020 7707 0707');

#
# Table structure for table 'Imprints'
#

DROP TABLE IF EXISTS `Imprints`;

CREATE TABLE `Imprints` (
  `ImprintID` INTEGER NOT NULL AUTO_INCREMENT, 
  `Imprint` VARCHAR(255), 
  INDEX (`Imprint`), 
  PRIMARY KEY (`ImprintID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'Imprints'
#

INSERT INTO `Imprints` (`ImprintID`, `Imprint`) VALUES (1, 'Undecided');
INSERT INTO `Imprints` (`ImprintID`, `Imprint`) VALUES (3, 'Addison-Wesley');
INSERT INTO `Imprints` (`ImprintID`, `Imprint`) VALUES (4, 'Longman');
INSERT INTO `Imprints` (`ImprintID`, `Imprint`) VALUES (5, 'Pearson');
INSERT INTO `Imprints` (`ImprintID`, `Imprint`) VALUES (6, 'Prentice Hall');
# 5 records

#
# Table structure for table 'Categories'
#

DROP TABLE IF EXISTS `Categories`;

CREATE TABLE `Categories` (
  `CategoryID` INTEGER NOT NULL AUTO_INCREMENT, 
  `CategoryName` VARCHAR(255), 
  INDEX (`CategoryID`), 
  PRIMARY KEY (`CategoryID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'Categories'
#

INSERT INTO `Categories` (`CategoryID`, `CategoryName`) VALUES (1, 'Business');
INSERT INTO `Categories` (`CategoryID`, `CategoryName`) VALUES (2, 'Computer Science');
INSERT INTO `Categories` (`CategoryID`, `CategoryName`) VALUES (3, 'Economics');
INSERT INTO `Categories` (`CategoryID`, `CategoryName`) VALUES (4, 'English');
INSERT INTO `Categories` (`CategoryID`, `CategoryName`) VALUES (5, 'Engineering');
INSERT INTO `Categories` (`CategoryID`, `CategoryName`) VALUES (6, 'Mathematics');
INSERT INTO `Categories` (`CategoryID`, `CategoryName`) VALUES (8, 'Statistics');
INSERT INTO `Categories` (`CategoryID`, `CategoryName`) VALUES (9, 'Student Success');
# 8 records

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `ID` int(11) NOT NULL,
  `CustID` int(11) NOT NULL,
  `ISBN` int(11) NOT NULL,    
  `BookName` varchar(255) DEFAULT NULL,
  `Category` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`ID`, `CustID`, `ISBN`, `BookName`, `Category`) VALUES
(1, 4, 0133360903, 'Building Java Programs', 'Computer Science'),
(2, 6, 0321836995, 'Mathematics All Around', 'Mathematics'),
(3, 24, 0321825721, 'Mathematics for Elementary Teachers with Activity Manual', 'Mathematics'),
(4, 10, 0133011208, 'Business Math', 'Business'),
(5, 10, 0321836960, 'Elementary Statistics', 'Statistics'),
(6, 15, 0321838696, 'Business Statistics: A First Course', 'Statistics'),
(7, 19, 0133485102, 'Managing Engineering and Technology', 'Engineering'),
(8, 2, 0133128911, 'Basics of Web Design: HTML5 & CSS3', 'Computer Science'),
(9, 2, 0133068307,' Introduction to JavaScript Programming with XML and PHP', 'Computer Science'),
(10, 3, 0133251241, "Horngren's Financial & Managerial Accounting", 'Business'),
(11, 18, 0132948850, 'Survey of Economics', 'Economics'),
(12, 18, 0132948869, 'Microeconomics', 'Economics'),
(13, 18, 0132991330, 'Macroeconomics', 'Economics'),
(14, 18, 0132992795, 'Macroeconomics,  2/e', 'Economics'),
(15, 16, 0132730359, 'E-Commerce 2013', 'Business'),
(16, 29, 0132993341, 'Fundamentals of Futures and Options Markets', 'Business'),
(17, 21, 0132991306, 'Modern Systems Analysis and Design', 'Business'),
(18, 25, 0321836960, 'Elementary Statistics', 'Statistics'),
(19, 25, 0321838696, 'Business Statistics: A First Course', 'Statistics'),
(20, 5, 0133255433, "Horngren's Financial & Managerial Accounting,  The Managerial Chapters", 'Business'),
(21, 5, 0133255573, "Horngren's Financial & Managerial Accounting. The Financial Chapters", 'Business'),
(22, 11, 0205890962, 'Mosaics: Reading and Writing Essays 6e', 'Student Success'),
(23, 30, 0133356712, 'Machine Design', 'Engineering'),
(24, 23, 0136015727, 'Reliability Engineering', 'Engineering'),
(25, 23, 0132832887, 'Aerodynamics for Engineers', 'Engineering'),
(26, 23, 0321899970, 'Technical Communication', 'English');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
